import torch
import torch.nn as nn
import torch.nn.functional as F
import timm
import numpy as np
from utils import misc
from utils.logger import *
from SoftPool import soft_pool2d, SoftPool2d
from .mask_encoder import Dit
from chamfer_dist import ChamferDistanceL1, ChamferDistanceL2 
def get_random_indices(n,m):

    assert m < n
    return np.random.permutation(n)[:m]
class VarianceSchedule(nn.Module):

    def __init__(self, config):
        super().__init__()
        
        self.config = config
        self.num_steps = self.config.generator_config.time_schedule.num_steps
        self.beta_start = self.config.generator_config.time_schedule.beta_start
        self.beta_end = self.config.generator_config.time_schedule.beta_end
        self.mode = self.config.generator_config.time_schedule.mode
        
        if self.mode == 'linear':
            betas = torch.linspace(self.beta_start, self.beta_end, steps=self.num_steps)
            
        betas = torch.cat([torch.zeros([1]), betas], dim=0)     # Padding
        alphas = 1 - betas
        
        alphas_cumprod = torch.cumprod(alphas, axis=0)

        self.register_buffer('betas', betas)
        self.register_buffer('alphas', alphas)
        self.register_buffer('alphas_cumprod', alphas_cumprod)

    # original sampling strategy
    # def uniform_sampling(self, batch_size):
    #     ts = np.random.choice(np.arange(1, self.num_steps+1), batch_size)
    #     return ts.tolist()

    # Recurrent Uniform Sampling Strategy
    def recurrent_uniform_sampling(self, batch_size, interval_nums):
        interval_size = self.num_steps / interval_nums
        sampled_intervals = []
        for i in range(interval_nums):
            start = int(i * interval_size) + 1
            end = int((i + 1) * interval_size)
            sampled_interval = np.random.choice(np.arange(start, end + 1), batch_size)
            sampled_intervals.append(sampled_interval)
        ts = np.vstack(sampled_intervals)
        ts = torch.tensor(ts)
        ts = torch.stack([ts[:, i][torch.randperm(interval_nums)] for i in range(batch_size)], dim=1)
        return ts


# Multi_scale_condition_generation_module
class Multi_scale_condition_generation_module(nn.Module): 
    def __init__(self, encoder_dims, cond_dims):
        super().__init__()
        self.encoder_dims = encoder_dims
        self.cond_dims = cond_dims

        self.res_block1 = self._make_res_block(encoder_dims, 512)
        self.res_block2 = self._make_res_block(512, 512)

        self.res_map = nn.Sequential(
        nn.Conv2d(512, 512, kernel_size=1, bias=True),
        nn.Sigmoid()
        )


        self.mlp1 = nn.Sequential(
            nn.Conv2d(self.encoder_dims, 512, kernel_size=1, bias=True),
            nn.ReLU(True),
            nn.Conv2d(512, 512, kernel_size=1, bias=True),
            nn.ReLU(True),
        )

        self.mlp2 = nn.Sequential(
            nn.Conv2d(1024, 512, kernel_size=1, bias=True),
            nn.BatchNorm2d(512),  ###
            nn.ReLU(True),
            nn.Conv2d(512, self.cond_dims, kernel_size=1, bias=True),
            nn.ReLU(True),
        )
    def _make_res_block(self, in_channels, out_channels):
        return nn.Sequential(
        nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=True),
        nn.BatchNorm2d(out_channels),
        nn.ReLU(True),
        nn.Conv2d(out_channels, out_channels, kernel_size=1, bias=True),
        nn.BatchNorm2d(out_channels),
        nn.ReLU(True))
    def forward(self, patch_fea):
        '''
            patch_feature : B G 384
            -----------------
            point_condition : B 384
        '''
        
        # patch_fea = patch_fea.transpose(1, 2)     # B 384 G
        # patch_fea = patch_fea.unsqueeze(-1)       # B 384 G 1
        # patch_fea = self.mlp1(patch_fea)          # B 512 G 1
        # # soft_pool2d
        # global_fea = soft_pool2d(patch_fea, kernel_size=[patch_fea.size(2), 1])  # B 512 1 1
        # global_fea = global_fea.expand(-1, -1, patch_fea.size(2), -1)            # B 512 G 1
        # combined_fea = torch.cat([patch_fea, global_fea], dim=1)                 # B 1024 G 1
        # combined_fea = self.mlp2(combined_fea)                                       # B F G 1
        # condition_fea = soft_pool2d(combined_fea, kernel_size=[combined_fea.size(2), 1])  # B F 1 1
        # condition_fea = condition_fea.squeeze(-1).squeeze(-1)                          #  B F
        # return condition_fea
        patch_fea = patch_fea.transpose(1, 2) # B 384 G
        patch_fea = patch_fea.unsqueeze(-1) # B 384 G 1

        # 通过残差块提取特征
        patch_fea = self.res_block1(patch_fea) # B 512 G 1
        patch_fea = self.res_block2(patch_fea) # B 512 G 1


        attention_map = self.res_map(patch_fea) # B 512 G 1
        patch_fea = patch_fea * attention_map # B 512 G 1



        global_fea = soft_pool2d(patch_fea, kernel_size=[patch_fea.size(2), 1])  # B 512 1 1
        global_fea = global_fea.expand(-1, -1, patch_fea.size(2), -1)   

        # 将局部特征和全局特征进行拼接
        combined_fea = torch.cat([patch_fea, global_fea], dim=1) # B 1024 G 1
        combined_fea = self.mlp2(combined_fea)
        
        
        condition_fea = soft_pool2d(combined_fea, kernel_size=[combined_fea.size(2), 1])

        condition_fea =  condition_fea.squeeze(-1).squeeze(-1)    # B  F
        return condition_fea


# Point Condition Network 
class PCNet(nn.Module):
    def __init__(self, dim_in, dim_out, dim_cond):
        super(PCNet, self).__init__()
        self.fea_layer = nn.Linear(dim_in, dim_out)
        self.cond_bias = nn.Linear(dim_cond, dim_out, bias=False)
        self.cond_gate = nn.Linear(dim_cond, dim_out)

    def forward(self, fea, cond):
        gate = torch.sigmoid(self.cond_gate(cond))
        bias = self.cond_bias(cond)
        out = self.fea_layer(fea) * gate + bias
        return out

# Point Denoising Network
class DenoisingNet(nn.Module):

    def __init__(self, point_dim, cond_dims, residual):
        super().__init__()
        self.act = F.leaky_relu
        self.residual = residual
        self.layers = nn.ModuleList([
            PCNet(3, 128, cond_dims+3),
            PCNet(128, 256, cond_dims+3),
            PCNet(256, 512, cond_dims+3),
            PCNet(512, 256, cond_dims+3),
            PCNet(256, 128, cond_dims+3),
            PCNet(128, 3, cond_dims+3)
        ])

    def forward(self, coords, beta, cond):
        """
        Args:
            coords:   Noise point clouds at timestep t, (B, N, 3).
            beta:     Time. (B, ).
            cond:     Condition. (B, F).
        """

        batch_size = coords.size(0)
        beta = beta.view(batch_size, 1, 1)          # (B, 1, 1)
        cond = cond.view(batch_size, 1, -1)         # (B, 1, F)

        time_emb = torch.cat([beta, torch.sin(beta), torch.cos(beta)], dim=-1)  # (B, 1, 3)
        cond_emb = torch.cat([time_emb, cond], dim=-1)    # (B, 1, F+3)
        
        out = coords
        for i, layer in enumerate(self.layers):
            out = layer(fea=out, cond=cond_emb)
            if i < len(self.layers) - 1:
                out = self.act(out)

        if self.residual:
            return coords + out
        else:
            return out


# Conditional Point Diffusion Model
class CPDM(nn.Module):
    def __init__(self, config, **kwargs):
        super().__init__()
        self.config = config
        self.cond_dims = self.config.generator_config.cond_dims 
        self.net = DenoisingNet(point_dim=3, cond_dims=self.cond_dims, residual=True)
        self.var_sched = VarianceSchedule(config)
        self.interval_nums = self.config.generator_config.interval_nums
    
    def get_loss(self, coords, cond, ts=None):
        """
        Args:
            coords:   point cloud, (B, N, 3).
            cond:     condition (B, F).
        """

        batch_size, _, point_dim = coords.size()

        if ts == None:
            ts = self.var_sched.recurrent_uniform_sampling(batch_size, self.interval_nums)

        total_loss = 0

        for i in range(self.interval_nums):
            t = ts[i].tolist()
            
            alphas_cumprod = self.var_sched.alphas_cumprod[t]
            beta = self.var_sched.betas[t]
            sqrt_alphas_cumprod_t = torch.sqrt(alphas_cumprod).view(-1, 1, 1)       # (B, 1, 1)
            sqrt_one_minus_alphas_cumprod_t = torch.sqrt(1 - alphas_cumprod).view(-1, 1, 1)   # (B, 1, 1)
            
            noise = torch.randn_like(coords)  # (B, N, d)
            pred_noise = self.net(sqrt_alphas_cumprod_t * coords + sqrt_one_minus_alphas_cumprod_t * noise, beta=beta, cond=cond)
            loss = F.mse_loss(noise.view(-1, point_dim), pred_noise.view(-1, point_dim), reduction='mean')
            total_loss += (loss * (1.0 / self.interval_nums))

        return total_loss
class VectorFieldPredictor(nn.Module):
    def __init__(self, point_dim, cond_dims, residual=True):
        super().__init__()

        self.act = F.leaky_relu  # 使用leaky_relu激活函数
        self.residual = residual  # 残差连接
        # self.var_sched = VarianceSchedule(config)  #时间步的方差调度器
        # self.interval_nums = self.config.generator_config.interval_nums  #从config中获取时间步的数量
        
        # 定义多个PCNet层
        self.layers = nn.ModuleList([
            PCNet(point_dim, 128, cond_dims + point_dim),   
            PCNet(128, 256, cond_dims + point_dim),
            PCNet(256, 512, cond_dims + point_dim),
            PCNet(512, 256, cond_dims + point_dim),
            PCNet(256, 128, cond_dims + point_dim),
            PCNet(128, point_dim, cond_dims + point_dim)
        ])

    def forward(self, x, t, cond):
        batch_size = x.size(0)
        t = t.view(batch_size, 1, 1).cuda()          # (B, 1, 1)
        cond = cond.view(batch_size, 1, -1).cuda()         # (B, 1, F)
        #time_emb = self.time_mlp(time)
       
        # t_norm = (t-1)/(self.var_sched.num_steps-1)
        t_emb = torch.cat([t, torch.sin(t), torch.cos(t)], dim=-1)  # (B, 1, 3)  128 1 3
        # print(t_emb.shape,"t_emb")
        cond_emb = torch.cat([t_emb, cond], dim=-1)    # (B, 1, F+3)
        
        out = x
        for i, layer in enumerate(self.layers):
            out = layer(fea=out, cond=cond_emb)
            if i < len(self.layers) - 1:
                out = self.act(out)

        if self.residual:
            return x + out
        else:
            return out
class RectifiedFlow_model(nn.Module):
    def __init__(self, config,  **kwargs):
        super().__init__()
        self.config = config
        self.vector_field_predictor = VectorFieldPredictor(point_dim=3, cond_dims=config.generator_config.cond_dims)
        self.dt = config.generator_config.dt
        self.var_sched = VarianceSchedule(config)  #时间步的方差调度器
        self.interval_nums = self.config.generator_config.interval_nums  #从config中获取时间步的数量
        self.Dit_depth = config.generator_config.Dit_depth
        self.Dit_num_heads = config.generator_config.Dit_num_heads
        self.trans_dim = config.encoder_config.trans_dim
        self.drop_path_rate = config.encoder_config.drop_path_rate
        dpr = [x.item() for x in torch.linspace(0, self.drop_path_rate, self.Dit_depth)]
        self.Dit = Dit(embed_dim=self.trans_dim,
        depth=self.Dit_depth,
        drop_path_rate=dpr,
        num_heads=self.Dit_num_heads,)
        # self.loss_func = ChamferDistanceL1().cuda()
        self.loss_func = ChamferDistanceL2().cuda()

    def create_flow(self, x_1, t, x_0=None):

        if x_0 is None:
           x_0 = torch.randn_like(x_1)  # 创建噪声点云
        # print(x_0.shape,"x_0" ,x_1.shape,"x_1", t.shape, "t")

        # t = t.cuda()
        # t_bar = (t-1)/(self.var_sched.num_steps-1) #128 1 1
        t = t.to(x_0.device)
        # print(t_bar.shape,"t_bar")   
        x_t = t * x_1 + (1 - t) * x_0
        return x_t, x_0

    # # def runge_kutta(self, x_t, v, dt):

    # #     k1 = v
    # #     k2 = v + 0.5 * dt * k1
    # #     k3 = v + 0.5 * dt * k2
    # #     k4 = v + dt * k3
    
    # #     x_t = x_t + (dt / 6) * (k1 + 2*k2 + 2*k3 + k4)
    # #     return x_t
    def euler(self, x_t, v, dt):
    #     """ 使用欧拉方法计算下一个时间步长的值
            
    #     Args:
    #      x_t: 当前的点云，维度为 [B, N, 3]
    #      v: 当前的速度（位移），维度为 [B, N, 3]
    #         dt: 时间步长
    #     """
         x_t = x_t + v * dt
         return x_t

    def flow_loss(self, coords, cond ):

        batch_size, _, point_dim = coords.size()

        # 使用 recurrent_uniform_sampling 方法生成时间步
     
        ts = self.var_sched.recurrent_uniform_sampling(batch_size, self.interval_nums)

        total_loss = 0

        # 逐步迭代时间步计算损失
        for i in range(self.interval_nums):
            t_current = ts[i].float().view(batch_size, 1, 1)  # 转换为浮点数并调整形状
            t_0 = t_current/(self.var_sched.num_steps-1)
            # Step 1: 生成噪声点云 x_t 和中间点云 x_0
            x_t, x_0 = self.create_flow(coords, t_0)

            # Step 2: 使用 coords 作为目标点云 x_1
            x_1 = coords  # coords 已经是目标点云

            # # Step 3: 预测向量场 v
            v_pred = self.Dit(x_t, t_0, cond)
            # v_pred = self.vector_field_predictor(x_t, t_0, cond)
            # print(v_pred.shape,"v_pred.shape")  128 1024 3

            # Step 4: 计算目标点云 x_1 和噪声点云 x_0 之间的差
            target_v = x_1 - x_0  # 目标点云与噪声点云之间的差
            # print(target_v.shape,"target.shape")  128  1024 3
            # Step 5: 计算 MSE 损失
            # loss = F.mse_loss(v_pred.view(-1,point_dim), target_v.view(-1,point_dim), reduction='mean')
            # loss = F.l2_loss(v_pred.view(-1,point_dim), target_v.view(-1,point_dim), reduction='mean')
            loss = self.loss_func(v_pred, target_v) #cdl1

            total_loss += (loss * (1.0 / self.interval_nums))  # 取平均损失

        return total_loss
    
    # def get_score_loss(self,x1,feat):

  
    #     x0 = torch.rand_like(x1)
    #     N_noisy = x1.size(1)
    #     # pnt_idx = get_random_indices(N_noisy,32)

    #     point_x0 = x0
    #     point_x1 = x1
    #     # print(point_x0.shape)
    #     B = x1.shape[0]
        
    #     t= torch.empty(B,1,1).uniform_(0, 1).to(x1.device)
    #     # print(t.shape)

        

    #     point_xt = t*point_x1 + (1-t)*point_x0
        
    #     grad_dir_t = point_x1 - point_x0

        
    #     pred_grad = self.Dit(point_xt,t,feat)


    #     # loss = (((pred_grad - grad_dir_t)**2.0)/self.sigema).sum(dim = -1).mean()
    #     loss = F.mse_loss(pred_grad.view(-1,3), grad_dir_t.view(-1,3),reduction='mean')
        
    #     return loss




    # def sample(self,cond,v_pred, num_step,num_points,device='cuda'):
        
    #     batch_size = cond.size(0)
        
    #     x_t = torch.randn(batch_size, num_points,3)
        
    #     for step in range(num_step):
    #         t = torch.full((batch_size,1,1),step/(num_step-1),device=device)
            
    #         t_0 = t/(self.var_sched.num_steps-1)
            
    #         v_pred = self.Dit(x_t, t_0, cond)

    #         x_t = self.euler()(x_t,v_pred,self.dt)

    #     return x_t