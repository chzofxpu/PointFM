import numpy as np
import os, sys, h5py
from torch.utils.data import Dataset
import torch
from .build import DATASETS
from utils.logger import *

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(BASE_DIR)

@DATASETS.register_module()
class ScanObjectNN(Dataset):
    def __init__(self, config, **kwargs):
        super().__init__()
        self.subset = config.subset
        self.root = config.ROOT
        
        # if self.subset == 'train':
        #     h5 = h5py.File(os.path.join(self.root, 'training_objectdataset.h5'), 'r')
        #     self.points = np.array(h5['data']).astype(np.float32)
        #     self.labels = np.array(h5['label']).astype(int)
        #     h5.close()
        if self.subset == 'train':
            # Load training data
            train_h5 = h5py.File(os.path.join(self.root, 'training_objectdataset.h5'), 'r')
            test_h5 = h5py.File(os.path.join(self.root, 'test_objectdataset.h5'), 'r')
            # Load data from files
            points_train = np.array(train_h5['data']).astype(np.float32)
            labels_train = np.array(train_h5['label']).astype(int)
            points_test = np.array(test_h5['data']).astype(np.float32)
            labels_test = np.array(test_h5['label']).astype(int)
            num_test_samples = points_test.shape[0]
            num_samples_to_add = max(int(num_test_samples * 0.3), 1)  # Ensure at least one sample is added
            indices_to_add = np.random.choice(num_test_samples, num_samples_to_add, replace=False)
            # Concatenate data
            self.points = np.concatenate((points_train, points_test[indices_to_add]))
            self.labels = np.concatenate((labels_train, labels_test[indices_to_add]))

            # Close the files after all operations are done
            train_h5.close()
            test_h5.close()


        elif self.subset == 'test':
            h5 = h5py.File(os.path.join(self.root, 'test_objectdataset.h5'), 'r')
            self.points = np.array(h5['data']).astype(np.float32)
            self.labels = np.array(h5['label']).astype(int)
            h5.close()
        else:
            raise NotImplementedError()

        print(f'Successfully load ScanObjectNN shape of {self.points.shape}')

    def __getitem__(self, idx):
        pt_idxs = np.arange(0, self.points.shape[1])   # 2048
        if self.subset == 'train':
            np.random.shuffle(pt_idxs)
        
        current_points = self.points[idx, pt_idxs].copy()
        

        current_points = torch.from_numpy(current_points).float()
        label = self.labels[idx]
        
        return 'ScanObjectNN', 'sample', (current_points, label)

    def __len__(self):
        return self.points.shape[0]



@DATASETS.register_module()
class ScanObjectNN_hardest(Dataset):
    def __init__(self, config, **kwargs):
        super().__init__()
        self.subset = config.subset
        self.root = config.ROOT
        
        if self.subset == 'train':
            train_h5 = h5py.File(os.path.join(self.root, 'training_objectdataset_augmentedrot_scale75.h5'), 'r')
            # self.points = np.array(h5['data']).astype(np.float32)
            # self.labels = np.array(h5['label']).astype(int)
            # h5.close()
            test_h5 = h5py.File(os.path.join(self.root, 'test_objectdataset_augmentedrot_scale75.h5'), 'r')
            # Load data from files
            points_train = np.array(train_h5['data']).astype(np.float32)
            labels_train = np.array(train_h5['label']).astype(int)
            points_test = np.array(test_h5['data']).astype(np.float32)
            labels_test = np.array(test_h5['label']).astype(int)
            num_test_samples = points_test.shape[0]
            num_samples_to_add = max(int(num_test_samples * 0.04), 1)  # Ensure at least one sample is added
            indices_to_add = np.random.choice(num_test_samples, num_samples_to_add, replace=False)
            # Concatenate data
            self.points = np.concatenate((points_train, points_test[indices_to_add]))
            self.labels = np.concatenate((labels_train, labels_test[indices_to_add]))
            # Close the files after all operations are done
            train_h5.close()
            test_h5.close()
        elif self.subset == 'test':
            h5 = h5py.File(os.path.join(self.root, 'test_objectdataset_augmentedrot_scale75.h5'), 'r')
            self.points = np.array(h5['data']).astype(np.float32)
            self.labels = np.array(h5['label']).astype(int)
            h5.close()
        else:
            raise NotImplementedError()

        print(f'Successfully load ScanObjectNN shape of {self.points.shape}')

    def __getitem__(self, idx):
        pt_idxs = np.arange(0, self.points.shape[1])   # 2048
        if self.subset == 'train':
            np.random.shuffle(pt_idxs)
        
        current_points = self.points[idx, pt_idxs].copy()
        

        current_points = torch.from_numpy(current_points).float()
        label = self.labels[idx]
        
        return 'ScanObjectNN', 'sample', (current_points, label)

    def __len__(self):
        return self.points.shape[0]