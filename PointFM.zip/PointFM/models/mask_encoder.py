import torch
import torch.nn as nn
import torch.nn.functional as F
import timm
from timm.models.layers import DropPath, trunc_normal_
import numpy as np
from utils import misc
from utils.logger import *
import random
from knn_cuda import KNN


class Encoder(nn.Module):   ## Embedding module
    def __init__(self, encoder_channel):
        super().__init__()
        self.encoder_channel = encoder_channel
        self.first_conv = nn.Sequential(
            nn.Conv1d(3, 128, 1),
            nn.BatchNorm1d(128),
            nn.ReLU(inplace=True),
            nn.Conv1d(128, 256, 1)
        )
        self.second_conv = nn.Sequential(
            nn.Conv1d(512, 512, 1),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True),
            nn.Conv1d(512, self.encoder_channel, 1)
        )

    def forward(self, point_groups):
        '''
            point_groups : B G N 3
            -----------------
            feature_global : B G C
        '''
        bs, g, n , _ = point_groups.shape
        point_groups = point_groups.reshape(bs * g, n, 3)
        # encoder
        feature = self.first_conv(point_groups.transpose(2,1))
        feature_global = torch.max(feature,dim=2,keepdim=True)[0]
        feature = torch.cat([feature_global.expand(-1,-1,n), feature], dim=1)
        feature = self.second_conv(feature)
        feature_global = torch.max(feature, dim=2, keepdim=False)[0]
        return feature_global.reshape(bs, g, self.encoder_channel)

class Group(nn.Module):
    def __init__(self, num_group, group_size):
        super().__init__()
        self.num_group = num_group
        self.group_size = group_size
        self.knn = KNN(k=self.group_size, transpose_mode=True)

    def forward(self, xyz):
        '''
            input: B N 3
            ---------------------------
            output: B G M 3
            center : B G 3
        '''
        batch_size, num_points, _ = xyz.shape
        # fps the centers out
        center = misc.fps(xyz, self.num_group) 
        # knn to get the neighborhood
        _, idx = self.knn(xyz, center)
        assert idx.size(1) == self.num_group
        assert idx.size(2) == self.group_size
        idx_base = torch.arange(0, batch_size, device=xyz.device).view(-1, 1, 1) * num_points
        idx = idx + idx_base
        idx = idx.view(-1)
        neighborhood = xyz.view(batch_size * num_points, -1)[idx, :]
        neighborhood = neighborhood.view(batch_size, self.num_group, self.group_size, 3).contiguous()
        # normalize
        neighborhood = neighborhood - center.unsqueeze(2)
        return neighborhood, center


## Transformers
class Mlp(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.fc1 = nn.Linear(in_features, hidden_features)
        self.act = act_layer()
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop = nn.Dropout(drop)

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x


class Attention(nn.Module):
    def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0.):
        super().__init__()
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = qk_scale or head_dim ** -0.5
        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

    def forward(self, x):
        B, N, C = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)

        x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x
def knn(x, k):
    inner = -2 * torch.matmul(x.transpose(2, 1), x)
    xx = torch.sum(x ** 2, dim=1, keepdim=True)
    pairwise_distance = -xx - inner - xx.transpose(2, 1)
    idx = pairwise_distance.topk(k=k, dim=-1)[1]
    return idx

def get_graph_feature(x, k=20, idx=None):
    batch_size = x.size(0)
    num_points = x.size(2)
    x = x.view(batch_size, -1, num_points)
    if idx is None:
        idx = knn(x, k=k)
    device = torch.device('cuda')
    idx_base = torch.arange(0, batch_size, device=device).view(-1, 1, 1) * num_points
    idx = idx + idx_base 
    idx = idx.view(-1)
    _, num_dims, _ = x.size()
    x = x.transpose(2,1).contiguous()
    feature = x.view(batch_size * num_points, -1)[idx, :]
    feature = feature.view(batch_size, num_points, k, num_dims)
    x = x.view(batch_size, num_points, 1, num_dims).repeat(1, 1, k, 1)
    feature = torch.cat((feature - x, x), dim=3).permute(0, 3, 1, 2).contiguous()
    return feature

class LEM(nn.Module):
    def __init__(self, dim=512, downrate=8, gcn_k=20):
        super(LEM, self).__init__()
        self.k = gcn_k
        self.dim = dim
        self.bn1 = nn.BatchNorm2d(self.dim//downrate)
        self.bn2 = nn.BatchNorm1d(self.dim)
        act_mod = nn.LeakyReLU
        act_mod_args = {'negative_slope': 0.2}

        self.conv1 = nn.Sequential(nn.Conv2d(self.dim*2, self.dim//downrate, kernel_size=1, bias=False),
                                   self.bn1,
                                   act_mod(**act_mod_args),
                                   )
        self.conv2 = nn.Sequential(nn.Conv1d(self.dim//downrate, self.dim, kernel_size=1, bias=False),
                                   self.bn2,
                                   act_mod(**act_mod_args))

    def forward(self, x, center):
        x = x.permute(0,2,1)
        idx = knn(center.permute(0, 2, 1), k=self.k)
        x = get_graph_feature(x, k=self.k, idx=idx)
        x = self.conv1(x)
        x1 = x.max(dim=-1, keepdim=False)[0]
        x1 = self.conv2(x1)
        x = x1.permute(0,2,1)

        return x
    
class BlockH(nn.Module):
    def __init__(self, dim, num_heads, mlp_ratio=4., qkv_bias=False, qk_scale=None, drop=0., attn_drop=0.,
                 drop_path=0., act_layer=nn.GELU, norm_layer=nn.LayerNorm, downrate=8, gcn_k=20, ad_layers=[11], layer_index=0):
        super().__init__()
        self.ad_layers = ad_layers
        self.layer_index = layer_index
        self.norm1 = norm_layer(dim)
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.norm2 = norm_layer(dim)
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)
        self.attn = Attention(
            dim, num_heads=num_heads, qkv_bias=qkv_bias, qk_scale=qk_scale, attn_drop=attn_drop, proj_drop=drop)
        if self.layer_index in self.ad_layers:
            self.cls = LEM(dim, downrate=downrate, gcn_k=gcn_k)
            self.cls_norm = norm_layer(dim)
    
    def denisity_select(self,full_denisity,num_points):
        _, N, _ = full_denisity.shape
        start_index =  N // 2
        select_points = full_denisity[:, start_index:start_index + num_points, :] 
        return select_points

    def forward(self, x, center_block):
        x = x + self.drop_path(self.attn(self.norm1(x)))
        x = x + self.drop_path(self.mlp(self.norm2(x)))
        if x.size(0) // center_block.size(0) == 2.0:
            temp = x[:center_block.size(0)]
        else:
            temp = x
        if self.layer_index in self.ad_layers:
            temp = temp + self.drop_path(self.cls(self.cls_norm(temp), center_block))
        if x.size(0) // center_block.size(0) == 2.0:
            return torch.cat([temp, x[center_block.size(0):]], dim=0)
        else:
            return temp
    
class TransformerEncoderH(nn.Module):
    def __init__(self, embed_dim=768, depth=4, num_heads=12, mlp_ratio=4., qkv_bias=False, qk_scale=None,
                 drop_rate=0., attn_drop_rate=0., drop_path_rate=0., downrate=8, gcn_k=20, ad_layers=[11]):
        super().__init__()
        self.blocks = nn.ModuleList([
            BlockH(
                dim=embed_dim, num_heads=num_heads, mlp_ratio=mlp_ratio, qkv_bias=qkv_bias, qk_scale=qk_scale,
                drop=drop_rate, attn_drop=attn_drop_rate,
                drop_path=drop_path_rate[i] if isinstance(drop_path_rate, list) else drop_path_rate,
                downrate=downrate, gcn_k=gcn_k, ad_layers=ad_layers, layer_index=i,
            )
            for i in range(depth)])

    def forward(self, x, pos, xyz):
        for _, block in enumerate(self.blocks):
            x = block(x + pos, xyz)
        return x 

class Block(nn.Module):
    def __init__(self, dim, num_heads, mlp_ratio=4., qkv_bias=False, qk_scale=None, drop=0., attn_drop=0.,
                 drop_path=0., act_layer=nn.GELU, norm_layer=nn.LayerNorm):
        super().__init__()
        self.norm1 = norm_layer(dim)
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.norm2 = norm_layer(dim)
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)
        self.attn = Attention(
            dim, num_heads=num_heads, qkv_bias=qkv_bias, qk_scale=qk_scale, attn_drop=attn_drop, proj_drop=drop)
        
    def forward(self, x):
        x = x + self.drop_path(self.attn(self.norm1(x)))
        x = x + self.drop_path(self.mlp(self.norm2(x)))
        return x


class TransformerEncoder(nn.Module):
    def __init__(self, embed_dim=768, depth=4, num_heads=12, mlp_ratio=4., qkv_bias=False, qk_scale=None,
                 drop_rate=0., attn_drop_rate=0., drop_path_rate=0.):
        super().__init__()
        
        self.blocks = nn.ModuleList([
            Block(
                dim=embed_dim, num_heads=num_heads, mlp_ratio=mlp_ratio, qkv_bias=qkv_bias, qk_scale=qk_scale,
                drop=drop_rate, attn_drop=attn_drop_rate, 
                drop_path = drop_path_rate[i] if isinstance(drop_path_rate, list) else drop_path_rate
                )
            for i in range(depth)])

    def forward(self, x, pos):
        for _, block in enumerate(self.blocks):
            x = block(x + pos)
        return x


class Mask_Encoder(nn.Module):
    def __init__(self, config, **kwargs):
        super().__init__()
        self.config = config
        # define the transformer argparse
        self.mask_ratio = config.encoder_config.mask_ratio 
        self.trans_dim = config.encoder_config.trans_dim
        self.depth = config.encoder_config.depth 
        self.drop_path_rate = config.encoder_config.drop_path_rate
        self.num_heads = config.encoder_config.num_heads 
        self.gcn_k = config.encoder_config.gcn_k
        self.ad_layers = config.encoder_config.ad_layers
        self.downrate = config.encoder_config.downrate
        self.num_neighbors = config.encoder_config.mask_neighbors
        self.num_to_keep = config.encoder_config.mask_num_to_keep
        print_log(f'[args] {config.encoder_config}', logger = 'Transformer')
        # embedding
        self.encoder_dims =  config.encoder_config.encoder_dims
        self.encoder = Encoder(encoder_channel = self.encoder_dims)

        self.pos_embed = nn.Sequential(
            nn.Linear(3, 128),
            nn.GELU(),
            nn.Linear(128, self.trans_dim),
        )
        dpr = [x.item() for x in torch.linspace(0, self.drop_path_rate, self.depth)]
        self.blocks = TransformerEncoderH(
            embed_dim=self.trans_dim,
            depth=self.depth,
            drop_path_rate=dpr,
            num_heads=self.num_heads,
            downrate=self.downrate,
            gcn_k=self.gcn_k,
            ad_layers=self.ad_layers
        )
        
        self.norm = nn.LayerNorm(self.trans_dim)
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv1d):
            trunc_normal_(m.weight, std=.02)
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)

    def _mask_center_block(self, center, noaug=False):
        '''
            center : B G 3
            --------------
            mask : B G (bool)
        '''
        # skip the mask
        if noaug or self.mask_ratio == 0:
            return torch.zeros(center.shape[:2]).bool()
        # mask a continuous part
        mask_idx = []
        for points in center:
            # G 3
            points = points.unsqueeze(0)  # 1 G 3
            index = random.randint(0, points.size(1) - 1)
            distance_matrix = torch.norm(points[:, index].reshape(1, 1, 3) - points, p=2,
                                         dim=-1)  # 1 1 3 - 1 G 3 -> 1 G

            idx = torch.argsort(distance_matrix, dim=-1, descending=False)[0]  # G
            ratio = self.mask_ratio
            mask_num = int(ratio * len(idx))
            mask = torch.zeros(len(idx))
            mask[idx[:mask_num]] = 1
            mask_idx.append(mask.bool())

        bool_masked_pos = torch.stack(mask_idx).to(center.device)  # B G

        return bool_masked_pos

    def _mask_center_rand(self, center, noaug = False):
        '''
            center : B G 3
            --------------
            mask : B G (bool)
        '''
        B, G, _ = center.shape
        # skip the mask
        if noaug or self.mask_ratio == 0:
            return torch.zeros(center.shape[:2]).bool()
        self.num_mask = int(self.mask_ratio * G)

        overall_mask = np.zeros([B, G])
        for i in range(B):
            mask = np.hstack([
                np.zeros(G-self.num_mask),
                np.ones(self.num_mask),
            ])
            np.random.shuffle(mask)
            overall_mask[i, :] = mask
        overall_mask = torch.from_numpy(overall_mask).to(torch.bool)

        return overall_mask.to(center.device) # B G
    
    def calculate_density(self,point_cloud):
        knn = torch.cdist(point_cloud,point_cloud)
        distances, _ = knn.topk(len(point_cloud), largest=False)
        density = 1.0 / (torch.mean(distances, dim=1) + 1e-6)
        return density
    
    def _mask_center_torus(self, center,num_neighbors=12,num_to_keep=4):
        B,G,_ = center.shape
        self.num_mask = int(self.mask_ratio * (G-(num_neighbors-num_to_keep)))
        
        mask_idx = []
        for point_cloud in center:
            density = self.calculate_density(point_cloud)
            center_point_index = torch.argmax(density).item()
            center_point = point_cloud[center_point_index]
            distances = torch.cdist(center_point.unsqueeze(0), point_cloud)
            indices = torch.argsort(distances)
            mask_indices = indices[:,num_to_keep:num_neighbors]
            mask = torch.zeros(len(point_cloud), dtype=torch.bool)
            mask[mask_indices] = True
            false_indices = torch.where(mask == False)[0]
            shuffled_indices = torch.randperm(len(false_indices))
            shuffled_tensor = false_indices[shuffled_indices]
            changed_indices = shuffled_tensor[:self.num_mask]
            mask[changed_indices] = True
            mask_idx.append(mask)

        bool_masked_pos = torch.stack(mask_idx).to(center.device)  # B G
        
        return bool_masked_pos    

    def forward(self, neighborhood, center, noaug = False):
        bool_masked_pos_torus = self._mask_center_torus(center,self.num_neighbors,self.num_to_keep )
        bool_masked_pos_rand = self._mask_center_rand(center, noaug = noaug)
        group_input_tokens = self.encoder(neighborhood) 
        batch_size, seq_len, C = group_input_tokens.size()

        x_vis_torus = group_input_tokens[~bool_masked_pos_torus].reshape(batch_size, -1, C)
        x_vis_rand = group_input_tokens[~bool_masked_pos_rand].reshape(batch_size, -1, C) 
        # add pos embedding
        # mask pos center
        masked_center_torus = center[~bool_masked_pos_torus].reshape(batch_size, -1, 3)
        masked_center_rand = center[~bool_masked_pos_rand].reshape(batch_size, -1, 3)

        pos_torus = self.pos_embed(masked_center_torus)
        pos_rand = self.pos_embed(masked_center_rand)

        x_vis = torch.cat([x_vis_torus,x_vis_rand],dim=0)
        pos = torch.cat([pos_torus,pos_rand],dim=0)
        # transformer
        x_vis = self.blocks(x_vis, pos, masked_center_torus)
        x_vis = self.norm(x_vis)
        
        x_vis_rand = x_vis[x_vis_rand.shape[0]:]
        group_input_tokens[~bool_masked_pos_rand] = x_vis_rand.reshape(-1, self.trans_dim)
        encoder_token = group_input_tokens

        return encoder_token, bool_masked_pos_rand
    
class TimestepEmbedder(nn.Module):
    def __init__(self, hidden_size,  frequency_embedding_size):
        super(TimestepEmbedder, self).__init__()
        self.hidden_size = hidden_size
        self.frequency_embedding_size = frequency_embedding_size


        self.dense1 = nn.Linear(self.frequency_embedding_size, self.hidden_size)
        self.dense2 = nn.Linear(self.hidden_size, self.hidden_size)

        nn.init.normal_(self.dense1.weight, mean=0.0, std=0.02)
        nn.init.normal_(self.dense2.weight, mean=0.0, std=0.02)

    def forward(self, t):
        x = self.timestep_embedding(t)
        x = self.dense1(x)
        x = F.silu(x) 
        x = self.dense2(x)
        return x

    def timestep_embedding(self, t, max_period=10000):
        t = t.float().cuda()
        dim = self.frequency_embedding_size
        half = dim // 2
        freqs = torch.exp(-torch.log(torch.tensor(max_period, dtype=torch.float32,device = t.device )) * torch.arange(start=0, end=half, dtype=torch.float32, device = t.device) / half)
        args = t[:, None] * freqs[None]
        embedding = torch.cat([torch.cos(args), torch.sin(args)], dim=-1)
        return embedding.to(t.dtype)
    
class FMT(nn.Module):
    def __init__(self, embed_dim=768, depth=4, num_heads=12, mlp_ratio=4., qkv_bias=False, qk_scale=None,
                 drop_rate=0., attn_drop_rate=0., drop_path_rate=0., **kwargs):
        super().__init__()
        hidden_size=384
        frequency_embedding_size = 256
        self.TimestepEmbedder = TimestepEmbedder(hidden_size,frequency_embedding_size )
        self.FMTBlocks = nn.ModuleList([
            FMTBlock(
                dim=embed_dim, num_heads=num_heads, mlp_ratio=mlp_ratio, qkv_bias=qkv_bias, qk_scale=qk_scale,
                drop=drop_rate, attn_drop=attn_drop_rate,
                drop_path=drop_path_rate[i] if isinstance(drop_path_rate, list) else drop_path_rate
            )
            for i in range(depth)])
        self.firstlayer = FirstLayer(embed_dim, in_channels=3)
        self.finallayer = FinalLayer(embed_dim, out_channels=3)
        self.decoder_pos_embed = nn.Sequential(
            nn.Linear(3, 128),
            nn.GELU(),
            nn.Linear(128, embed_dim)
        )
        self.fc1 = nn.Linear(embed_dim,embed_dim*2)

    def forward(self, x, t, cond):
        B_x,N_x, _  = x.shape
        te = self.TimestepEmbedder(t)
        te = te.view(B_x,-1)
        ye = cond
        c = te + ye
        x = self.firstlayer(x)
        x = x.view(B_x,N_x,-1)
        for _, block in enumerate(self.FMTBlocks):
            x = block(x, c)
        x = self.finallayer(x, c)
        return x 
    
class FirstLayer(nn.Module):
    def __init__(self, hidden_size, in_channels):
        super(FirstLayer, self).__init__()
        self.in_channels = in_channels
        self.hidden_size = hidden_size
        self.conv1 = nn.Conv1d(in_channels=self.in_channels, out_channels= self.hidden_size // 2, kernel_size=1)
        self.conv2 = nn.Conv1d(in_channels=self.hidden_size // 2, out_channels= self.hidden_size, kernel_size=1)
        self.layer_norm = nn.BatchNorm1d(self.hidden_size // 2)
        
    def forward(self, x):
        x = self.conv2(self.layer_norm(self.conv1(x.permute(0,2,1))))   
        return  x.permute(0,2,1)

class FinalLayer(nn.Module):
    def __init__(self, hidden_size, out_channels):
        super().__init__()
        self.out_channels = out_channels
        self.hidden_size = hidden_size

        self.dense1 = nn.Linear(self.hidden_size, 2 * self.hidden_size)
        self.layer_norm = nn.LayerNorm(self.hidden_size)
        self.dense2 = nn.Linear(self.hidden_size, self.out_channels)
        
    def forward(self, x, c):
        c = F.silu(c)
        c = self.dense1(c)
        shift, scale = torch.split(c, self.hidden_size, dim=-1)
        x = self.layer_norm(x)
        x = modulate(x, shift, scale)
        batch_size, seq_length, num_features = x.shape
        x = x.view(batch_size * seq_length, num_features) 
        x = self.dense2(x)
        return x.view(batch_size, seq_length, self.out_channels)   

class FMTBlock(nn.Module):
    def __init__(self, dim=384 , num_heads = 4, mlp_ratio=4., qkv_bias=False, qk_scale=None, drop=0., attn_drop=0.,
                 drop_path=0., act_layer=nn.GELU, norm_layer=nn.LayerNorm, **kwargs):
        super().__init__()
        self.hidden_size = dim
        self.silu = nn.SiLU()
        self.split_hidden_size = 6 * self.hidden_size
        self.fc1 = nn.Linear(self.hidden_size, self.split_hidden_size) 
        self.norm1 = norm_layer(dim)
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.norm2 = norm_layer(dim)
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)
        self.attn = Attention(
            dim, num_heads=num_heads, qkv_bias=qkv_bias, qk_scale=qk_scale, attn_drop=attn_drop, proj_drop=drop)
    def forward(self, x, c):
        c = self.silu(c)
        c = self.fc1(c)
        
        shift_msa, scale_msa, gate_msa, shift_mlp, scale_mlp, gate_mlp = torch.split(c, c.size(-1) // 6, dim=-1)

        x_norm1 = self.norm1(x)
        x_modulated = modulate(x_norm1, shift_msa, scale_msa)
        x = x + gate_msa[:, None] * self.drop_path(self.attn(x_modulated))
        x_norm2 = self.norm2(x)
        x_modulated2 = modulate(x_norm2, shift_mlp, scale_mlp)
        x = x + gate_mlp[:, None] * self.drop_path(self.mlp(x_modulated2))
        return x 
def modulate(x, shift, scale):
    return x * (1 + scale[:, None]) + shift[:, None]